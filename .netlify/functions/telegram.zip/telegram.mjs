
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/telegram.mjs
var telegram_default = async (req) => {
  if (req.method !== "POST") {
    return new Response("Nur POST erlaubt", { status: 405 });
  }
  let data;
  try {
    data = await req.json();
  } catch {
    return new Response("Ung\xFCltige Daten", { status: 400 });
  }
  if (data.botcheck) return new Response("OK");
  const clean = (value, max = 300) => String(value ?? "").trim().slice(0, max);
  const name = clean(data.name, 100);
  const kontaktweg = clean(data.kontaktweg, 150);
  if (!name || !kontaktweg) {
    return new Response("Name und Kontakt fehlen", { status: 400 });
  }
  const text = [
    "\u{1F514} Neue Anfrage \xFCber die Website",
    "",
    "Name: " + name,
    "Betrieb: " + (clean(data.betrieb, 150) || "\u2013"),
    "Kontakt: " + kontaktweg,
    "Thema: " + (clean(data.thema, 50) || "\u2013"),
    "",
    clean(data.msg, 1500) || "(keine Nachricht)"
  ].join("\n");
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    return new Response("Telegram ist nicht eingerichtet", { status: 500 });
  }
  const res = await fetch("https://api.telegram.org/bot" + token + "/sendMessage", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text })
  });
  if (!res.ok) {
    return new Response("Telegram-Fehler", { status: 502 });
  }
  return new Response("OK");
};
export {
  telegram_default as default
};
